vec.norm <-
function(A){					
	sqrt(t(A)%*%A)
}
