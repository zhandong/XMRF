GMS <-
function(x, ...) UseMethod("GMS")
