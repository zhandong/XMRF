.onLoad <- function (lib, pkg)   {
     library.dynam("XMRF", pkg, lib)
  }
